--------------------
Snippet: GoogleSiteMap
--------------------
Version: 1.2
Created: June 23, 2009
Author: Shaun McCormick <shaun@modx.com>

- Based on Michal Till's MODx Evolution GoogleSiteMap_XML snippet

This component builds the GoogleSiteMap XML for you.
    
Example:
[[!GoogleSiteMap]]