<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cbc50acc4b6bc579ae96acf04f91519a',
      'native_key' => 'core',
      'filename' => 'modNamespace/ab6de00b670f7a399176c77617c70b39.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '2a3ca237e1083789a023da4adb3c03dd',
      'native_key' => 1,
      'filename' => 'modWorkspace/e8b328b528a11bd400aa0195aef39182.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'fc6d452202d932323afe809b1b68dd58',
      'native_key' => 1,
      'filename' => 'modTransportProvider/dc3430aa3d539b41761c89cf230624ab.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '23a03774d740b0486addb1ec7c0e1b77',
      'native_key' => 1,
      'filename' => 'modAction/15ac03949c02e11954a39dd32e476bab.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4b00ac5a479854fa2ec339ff1ed40227',
      'native_key' => 3,
      'filename' => 'modAction/c647713fe7b26708cbe670d80ee9f3ba.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '8f5ffb339bd3a9fb386e18031577df92',
      'native_key' => 5,
      'filename' => 'modAction/75299955e5eb0e287b46160345e773a1.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7030a5b3be9890844c17b1422fc03aa7',
      'native_key' => 7,
      'filename' => 'modAction/5bed94d756bff599972e3b30299b6981.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f4252dbb05544ac9a550db79d927a032',
      'native_key' => 8,
      'filename' => 'modAction/f4a8ee5119ab8fbc9afac867b5704d93.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '39ed1ff029655ff0fefe24a0d45744c1',
      'native_key' => 9,
      'filename' => 'modAction/270e19da92a8a5dbf5cebc02798f39f7.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c7513ff8b7a4d397d188e34fa7968871',
      'native_key' => 10,
      'filename' => 'modAction/79bc0271ae7abdf05fe1a055d5345b21.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7964771810080d72a3319b0e63619500',
      'native_key' => 11,
      'filename' => 'modAction/8276cb435d9ed1fdb88c694d7db006d7.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '04301215d2d854e12cf1788a0693d778',
      'native_key' => 12,
      'filename' => 'modAction/2b44a4c3bb49a66ecc5d84f78de0fd10.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'bcb2ce0e4f37ebea51314fa290913312',
      'native_key' => 13,
      'filename' => 'modAction/232e9373b28674810af3a89f827138bb.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7e0859a0c8d4b0adee5512126814f79a',
      'native_key' => 20,
      'filename' => 'modAction/e10dbceaa9904aaefac1f61c21dc8709.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7b2563d7c31e9cbec338fc46cfd934f5',
      'native_key' => 21,
      'filename' => 'modAction/23a0e8fcb279e83f7e5cd95695e7877a.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f94279646157ac7d7e0b5bbb35442d73',
      'native_key' => 22,
      'filename' => 'modAction/4b87f91a70ffc6f0ed294cfc1def56f9.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'cd0178f204ccab42d9ac03819b0c048c',
      'native_key' => 25,
      'filename' => 'modAction/f90063367a53bb07bbc88aea2f933650.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f69854ffb90a21fec89468fc10c7fec0',
      'native_key' => 26,
      'filename' => 'modAction/c817dd46ca61d231fb0f694712ad8f78.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '211c9572d9ead0adb2c5663d29367854',
      'native_key' => 27,
      'filename' => 'modAction/356746b3b9ffe775252bf7e3b2e27661.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '711ea32a517fd67bfb84809929738428',
      'native_key' => 28,
      'filename' => 'modAction/a781c0742a4026b611fd3fc5930c11f4.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '71046adc20b88ea06b4919879172e6e9',
      'native_key' => 29,
      'filename' => 'modAction/86e0f4f7950eddd3532522371a5e139c.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '8609def72a8a3c01042bd7b1a26c3fa4',
      'native_key' => 30,
      'filename' => 'modAction/16d683d2ac7b1649e9e6507a938d93c8.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'fd0ecfee3af7e98120b71bb6628bfb4c',
      'native_key' => 31,
      'filename' => 'modAction/76d96fa9d1db114da1361753e2ed7a9d.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd3deaec97585ba7388e67f97075340f7',
      'native_key' => 32,
      'filename' => 'modAction/a78e5136fd8c394df861456e4569f0aa.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5120ab1abcc4eadd7d5d6d5bca14e8cd',
      'native_key' => 33,
      'filename' => 'modAction/285eddf251d823eb3251e0494a19e0b9.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f3c97d057d0f4d362ffe1af75ffeec67',
      'native_key' => 34,
      'filename' => 'modAction/5696c0df88f2bdb1c20798127107adee.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7ee0dcc98daba15edd2ed2080523fc14',
      'native_key' => 35,
      'filename' => 'modAction/bcf78961cc23842dd11b117eb3fa05cf.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'db313230f092bc075f798e58f19cdfb9',
      'native_key' => 36,
      'filename' => 'modAction/3638c3f04d1218bb59aff712d611c028.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '20d5fb89c16d283aaf958c3f42c5e071',
      'native_key' => 38,
      'filename' => 'modAction/aaf9c04e149827a8b800c086b10782ea.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'aecc9f917234624e7ed293fb52e0283b',
      'native_key' => 39,
      'filename' => 'modAction/86bb4712624c76fddd1a4b44178b4754.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5bb2d24d35a32de6a49a6210940bbb21',
      'native_key' => 40,
      'filename' => 'modAction/c47eb34114625eee20081211ecdc88ae.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0cd08daa5e12336d4ca670fdf51ec8d8',
      'native_key' => 41,
      'filename' => 'modAction/e682325479d177043f4e240742702a49.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '9f87b8b7cf70b68eff4041d700f155d9',
      'native_key' => 43,
      'filename' => 'modAction/b47f496929b878da5383393c050d604a.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '18717388b896dd4d135b57f15e73d4f0',
      'native_key' => 46,
      'filename' => 'modAction/9347944dda451f0c54d3ba1f08a59e86.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd6dbfb859aa15b0619b1c6baa4106bab',
      'native_key' => 50,
      'filename' => 'modAction/d5073dae5bf54643b046c4f3904b239d.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '34d16ad2a62836c1ad0d8413d95e8ef6',
      'native_key' => 54,
      'filename' => 'modAction/7b35a061227b54a77fd8c2addef5828b.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'a87776043500cf2900764caa4bd83a3e',
      'native_key' => 55,
      'filename' => 'modAction/c919311b3236a0f7c974ed17a1871080.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '396f9e601ea4d2fe18b44018e2e9c658',
      'native_key' => 56,
      'filename' => 'modAction/2ff25dcdb9a00d39c233cf5630ccaaae.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0f97ffd3a9637db85640f439c73dd6de',
      'native_key' => 62,
      'filename' => 'modAction/73d83703b45518a15ffe84c1c526b69f.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '11bb78fdaa3b6783a93f8393510205c1',
      'native_key' => 64,
      'filename' => 'modAction/3ac9398bdb3530169b1806f18c94628a.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b6fa1d4147b0b1455bcea4d6795e3425',
      'native_key' => 67,
      'filename' => 'modAction/9493c364d96430068c8100df8beadc67.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1a9b4041c2559e3107507fa818e97a23',
      'native_key' => 70,
      'filename' => 'modAction/e77efebf15ae0ccb20547c5bcefadc4f.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '59287901376d14595b28bb553f580761',
      'native_key' => 71,
      'filename' => 'modAction/63ba6c3cb425f4b4ec005a5f0fb48a34.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '28dfbf3d0c2750c6abe10eabfc0538cf',
      'native_key' => 75,
      'filename' => 'modAction/0e422c7cb05fd4a9b9b588df4bcd63e2.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '33cb704531f367cd372a627d872292c5',
      'native_key' => 82,
      'filename' => 'modAction/e680bc1101e995f63e9c91d198d9886b.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1af20ddd19fbf0f95aff1c9e13b12934',
      'native_key' => 83,
      'filename' => 'modAction/6f6c4f6cf00a9d575a369239361579c3.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '54d9d7adfb2bfd0dd0fe5f5396d992c2',
      'native_key' => 84,
      'filename' => 'modAction/184b3da963581f1ffdd6e669becf35ba.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ef6a11549e8a76b7840a43b130c00da1',
      'native_key' => 85,
      'filename' => 'modAction/de66eeeabf9b2c730dd57bae0ba7d10c.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'dbc70c5db2a6a9e64a3eb8cf2c9d26de',
      'native_key' => 101,
      'filename' => 'modAction/1fb906c0d4c22db27de104df4b2c85f4.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '82c52aa3195dec2c2fa91a99adb48e1e',
      'native_key' => 102,
      'filename' => 'modAction/5324179b1f4661b281bc6874aa0411ad.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '01c38aeb3984589a345aa70c673f6b19',
      'native_key' => 103,
      'filename' => 'modAction/f3f5ec868e9cba6c989cb8d56b88c3e4.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1b173e7de418d664206dc8b6e8660aaa',
      'native_key' => 104,
      'filename' => 'modAction/e75afc42b4a533361386e6c9f5c460c3.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'fbbb23756b2f73d718520cadd0ac3f25',
      'native_key' => 105,
      'filename' => 'modAction/708297612f7c4cbd2fcc0945b0559f97.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '9838b6f2cf11c1bbafc0cdc55d5db096',
      'native_key' => 106,
      'filename' => 'modAction/112258434c659cde871c11f1206f3365.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '50fa171bea4ab886420287fedc1c8e94',
      'native_key' => 107,
      'filename' => 'modAction/d224e69c7463f224af4c049131adb95c.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6a304804a306a010ecc72e309b5f0bf5',
      'native_key' => 'dashboard',
      'filename' => 'modMenu/3ec54bc18b957a06f872f50350905ada.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ea58b22612e6ecd1881785cb4a57860d',
      'native_key' => 'site',
      'filename' => 'modMenu/0e8db641282cd474c1ba00155351955b.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0416b9589833b8910815f74a471deffd',
      'native_key' => 'components',
      'filename' => 'modMenu/6cad60d47574151b9bb7b3e26dce5a03.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7d2f4c53639a2398c5d14c3c59686c1b',
      'native_key' => 'security',
      'filename' => 'modMenu/cd7e500e05b6e6582088550f58e5f2ed.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4130fd16a35c012a4126515d73210a3d',
      'native_key' => 'tools',
      'filename' => 'modMenu/f4d71eaa0d51a1bfc54f64967ed67027.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c5334b153fb38b8cf4bcb614543633fa',
      'native_key' => 'reports',
      'filename' => 'modMenu/98bb7154ed0e9b1d4c90122fd6822d75.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '36a63334a99d88f5e65d8e170bdaa251',
      'native_key' => 'system',
      'filename' => 'modMenu/6700906dc03ec36ac16a53d07fd5ba07.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '54b1b847272f848e9e72518743d74df9',
      'native_key' => 'user',
      'filename' => 'modMenu/e655e5c5cecf66eb4220edb0eb5a37ed.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '46999a20e8caec0ca04be0916b5a9662',
      'native_key' => 'support',
      'filename' => 'modMenu/426a7432ac85d549ade3a1722c3b1179.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3c54aecb2f9e5206b2b26b28f582d97f',
      'native_key' => 1,
      'filename' => 'modContentType/aee90f27bde13f9b327db07d23872093.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c20fe83f6d4a0b854ffe7ca71974f7ef',
      'native_key' => 2,
      'filename' => 'modContentType/f0a12dff0213b65a223053e00a16c042.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '34d30d855a5f8f63975cfed09c76de8f',
      'native_key' => 3,
      'filename' => 'modContentType/b4aaad5d1b2702c0bd2c5bc953c031d9.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '481fee092301c8976f0fb1c57bf15800',
      'native_key' => 4,
      'filename' => 'modContentType/536dcbe4b2e75b2a8f811d22d8dc4d13.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '09279f394668d0aa63982cd66092c825',
      'native_key' => 5,
      'filename' => 'modContentType/d6caac65303ed5b66b9bb65d1f20e532.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8e0ce9a3c34876b3330e8d0d7be38685',
      'native_key' => 6,
      'filename' => 'modContentType/d481cdbc49f924f53bb3061f839cfa0f.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f6e9ec6ab2b00fe20a78154c3251229b',
      'native_key' => 7,
      'filename' => 'modContentType/da472eb3914aab762fe2b934f281e805.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '12ea0955681f59b3aa7833d8aa80148a',
      'native_key' => NULL,
      'filename' => 'modClassMap/e8db299123b949e91e54f0dd80565b9b.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '52388c08bbebc38260fbd098413475e5',
      'native_key' => NULL,
      'filename' => 'modClassMap/097ef05a26e06ca8c39ddd4bea02bb40.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '90e9fd35d793b2208c01bb9a8f749e4d',
      'native_key' => NULL,
      'filename' => 'modClassMap/fb480a14783ac3e31b2f10ebf0eb1425.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'fe407aeb43a8f8eb027e49dd49f695d8',
      'native_key' => NULL,
      'filename' => 'modClassMap/49f39d75759f162177e48a6ba08484b2.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '13e5bc301256b3e7d1dae0036899c7eb',
      'native_key' => NULL,
      'filename' => 'modClassMap/86033b24f679f1123d3cab0cdbace248.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2e6f9ad8a0abbd4a6899ab5ba26851b2',
      'native_key' => NULL,
      'filename' => 'modClassMap/1715836e9d01c394420c41eee0f85dc5.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2f4446b4d826f4ab291a35f502018882',
      'native_key' => NULL,
      'filename' => 'modClassMap/270e705ff5e8afe4f487f0bec6a38bbc.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6a025f7bd9cdf85a7c786e5b9d9566cf',
      'native_key' => NULL,
      'filename' => 'modClassMap/26cea1af6bbf748476e3793b1c375908.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c7a4e474786a1b98e0b05fc37081ecc6',
      'native_key' => NULL,
      'filename' => 'modClassMap/8af54ce1e193843ac9cad0cae2b61034.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32f9b05fc306e122172cb93c3b2d7f84',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/7f4201892c35dcbfffb59d4ffde4bb2f.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a75ec75437d7d8bee87e11916894b6fe',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/7c4e49d4cb42a88637ee10e53105e9e2.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa71b13595076e746d3452e648e91987',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/e0b65d1b395fec5bb78067bd58c3338d.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '169c8afcef8c84db8e336815bdc94e36',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/8149dfa1981669e025caffcb3b64cd54.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17ff2e370d0c04bba51739c26a63278a',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/a6ee4ac439cde606661e337bccea73fb.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88325174acf3bf0042b804336a4aab0e',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/9e71aa3e2c13f579c31250c9352bd672.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea54435e96c8fb0a78496993a02bc4b4',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/16988b7e221ac6caedd0b133d1d7368d.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b06faf84d727dd900c18c4e85d0c702',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/06aba7bce0cf3e7c3ec9353d7264d9a1.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc2d1caa3cd3f24e4e4be13f6552e07f',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/5b7a195c810fccdf047ab0ea68b80ad9.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b487918b817bcf70efc8909cccd751c',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/0a51c3cdd1abbae54baa9429f0cfdd4a.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97b961fb0d847a0ad037ea8b073bff54',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/32670e38c43b8915e7bb2eb92ed7a9ea.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa06e2c5389addf94a0b73d369d21dcc',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/2107b7208a167c9e4825850767246953.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47331fae643cea88881a5f1d430136bf',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/41b4f241443b405a20fcb9232f670fd4.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55a42f526b4a72112d5eac4c4c413dda',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/441959f114fe8e125353ee0ed3e55cfc.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91eecaa45035bba735c226ffce36c6c5',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/1af195830103387d5ecbc7862634962f.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea69e09194fb25a5b5a5bf5b9b4734ac',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/55a2dc73112faff324226a9d0059a038.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9e78ddc951dbf23665f40b9052d0f55',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/bfc1011bac9dfa14cc60de0901e6d031.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6119b966be78e4ef933e08ec2698a936',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/06c254053550bf3cf96b36b5bc065b9c.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a07304b4aadfd8fde3df900d4ab79536',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/f33afbec64e8e27736fc24b1a1d44364.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a06e72a7e98e28d2c1e7faf8a3e0d95e',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/c3b48547e9060d53fc29c9c1d5fdb672.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1e371bc1c6aa3b52f49b36a524cfea8',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/33cb1e780c03a9f731b64a89de2111a8.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95401fa9128dacf01aca98d838869c0c',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/8733ed3eb791d6f5f3120f669283728b.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aae67736fec77c1fd17ed491395fe6b3',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/de89eaa4966ac371e9496fc6063d3e3f.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d2862b1f44f5e1ce7d64370f0bace29',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/743aa83efe5c35cc897d30dce2aee938.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88b4dcfa3add8477eeee57342e8c7b9d',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/b65a545bcdebede6f8123680ad5fc4b8.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b8625f33e7c4164b3c7149910f0d303',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/3283a46ecf48692b34597fa8ea001b95.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4285c419289080211f3b671d7e3fde3',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/98449214afe082e18acf9cdb721f47cf.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8eecf69adba81bd61ebf1aeccd5acbe9',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/4dd93b19603786d9cb1b69789ac77fd1.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5da4b77c0527a9300bf9c626ede0cde',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/a0eae9f811f9e2c789c12966d5d73f29.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4eca4bc7de304e6a3ac4c2e1bff4ce25',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/6763327303de8af60abba11c1abf3ea3.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b20c4a572d87b8c802b071fe71e978b',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/159b6c69386d437c70b876061860518b.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f483b30f84a180ebdba3685b785b525',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/ec3ec93603f14d37af94a7d386bc4087.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e2152c0a8b9e47cdc537b701bc9f75a',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/d4a4a8336365ae55e9c7f27486689a7e.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8283089652156e272db02c36cf4d552a',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/9e8b9d9d2781d08bf165c605e59ac3a5.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2790756876cd331c8f44c49bd239666c',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/c462a548ab280137e4d9fa0ffab5bdf3.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e4a58690c9c6cf35a7417168d078b9d',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/70f32d6fa6a44d74318192d7c57d439a.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5717b5dbd029194e06f719cc0cf970a1',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/b921b3eb2a8866ffef5055a11c48f7c7.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6eb10cea8006b9ea15fb8425ca82530',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/b1cd90cf33eb5a5db10e3dc01af0a272.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82d5807d2fb4ef85b8d585aec849a6f7',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/7af4dee6a3492abd9f28ffcb3576bbc6.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db498581fa37f549f2bf50012f008b2d',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/325470d684bb4e01f39706b1b850a0c6.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '136020b4d58baba11e42c9cf7307f831',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/656f54379ebc53c5d2d6a072a16b1559.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8e823eeace1f1a5b64679ea55a5d3fc',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/37f2a6fc00789226282450543aefc3c9.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81adad8e440ee3e52f51a78975ca5ee0',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/98ae56a4b60d49029b4e90aa5a0ba042.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6345a73b5199c86a4c7dc318e979b40',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/3368b4e2258718f02a0ac6d2f1144398.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c967d1f038a44a4bcd13da2f4beed935',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/f4faa39f58db6dd8349b8cf333131cab.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d25f25cbef2581e7a6a894f96034ed7',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/eb8e92c7995290c94eae82657bd94f56.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f9f9e1534a806d8dd4064e3d39066ae',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/1a079bcd3937271dba181689a60c3412.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46baf6a8f1ce837e3c32cd226b376f21',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/a305612bb3b1b6c9ddd30e456e0ee0fa.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22eaf134de904955cf745348afedebef',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/7dac233f90a600ed4a7a004a9fea5e1b.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cd5fb00c40fc3fd586b7dd845bf35ed',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/1ab594537ec111d645edc495179c0934.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45fcdd63e7290579aa3ca6abd57f274d',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/b4dd12de0730502d4859e5b82387233d.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '903b59a533b827a080e32bd5e629f7be',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/8934db558ef84b0b087b68c99e7af7e4.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1152b43804d1e4dd6f1431507deef5e',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/9153fbbaf640a0567a1a23e74779af42.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8da5a90265d54867571bb53073e56723',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/3d0eff47f6f78181cdf195b67cc353ec.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '319952f3c5f3e570d018d4c35b641f44',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/4159c2e733190198e8a236c079085c3d.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '664b973ae6c6b9e41ae1b5cac937527d',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/89d7f01315b6cb77ec2b00c0d3db0728.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b995bdb1bf30fa4627cd1e7f5f843c2',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/a9d57ee3c1f0758c47f737dbbefe50bf.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '690fa1c7e0dbd93929908b7a73246f43',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/ec905d54f9ea118ed309b28a090ba5c8.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '455309456300ed4aff050e2fb2a73cd8',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/27d0d536e6690ea498d4d4b2e7476560.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edc76e3a3d9e7629e4b600ef22db5474',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/e1adb201d8ced3b9bc30705fe84088ea.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59211a49831459e3d5c5db7a4c59d6fd',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/e864df4e30a1db98aba0a13054248573.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86da08f6994f6e1de6e9cb073af49377',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/1485e5afa452964920db3dad8b27dbee.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ca34458f1d3e3d0a2d77fd5b5cab79d',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/37bf55482404cc02683f3a9a866b6db6.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76fee74a3bd4a168baeb60b0b49e6810',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/9e9a626b23dcf1a4aec346fea3cd686c.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48ef70d24b767e3475b0f4d46598507e',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/99d57c201ca889a6117a983768968099.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37d704736a4e9e939de610605e05571f',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/c1257cd512880cafab349a870ab27cc4.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8413b9d8edbe184f304c56ea6b1e43d2',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/608fb9f66a4e8a1fdd0014cd26a9bbd1.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c06ee4abd9a21b98ae20886eb6a155b',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/5854ce42b041d19d924e89634e314372.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0d2abd518140eee42617448c946032e',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/974e968c606131addd18fe1193ebead5.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8533fd21f2397b6392627872024599a',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/6e0c50e4a3d07baf5c218a29e2a3aa96.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05f2438d7cf787b3c0afe26989c1a631',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/e56309d732bbb8ec226417b879999cc8.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f21e6576903c9f22abfb874b0e9e213',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/a285d3dfa8ce8386471461950e5fb99e.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a00a5b72dafc2e156b2e5d9cd545347',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/e3c91012c2ba7d1cb6f76f31efc3b4ba.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6380a3f482f86b16fd866f43f07ad02d',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/2f5f1f492aa7d8d00aa42fd55af6f115.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7a99fa600e5bb7c8849d9b73a510b80',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/c4847f5b1c596ab93ac266c7942c9b95.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc3961e3dae300f8b78adc543befedc7',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/550f54ba0e54c7c47b7eb39500f6b2c1.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b6c317fa2a569f6020098ab5b4071d2',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/e9018045c0ab1da7c39e45d48f36d01b.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9a776d31941437ccab76dfb3af934c7',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/fefc68287ba12a3bfb03cf2b97ac54b6.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9121e7521d074f19a1d6587cd5e83b9',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/2b7e2e1368c39eadba4be78323bfa846.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '24ea2dac69412b890b2ec7cedbc7326e',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/5c47bfc21f021839377e5e8a05bf33c1.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b8b537698d06e0c826c589dd18d185c',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/5678d117c1e101e13cf0b821eb5db3df.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a99c4119322d73a84b1944b8c8775118',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/428ea2189885ddf1a433aa72f86dd426.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd8a85971bd7f79a1094d46a76514c28',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/b979db9cbb485464097e1b5b811a40d3.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '279db359a7e3921cfbb7c885f6dbd8bc',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/dadf6f399ca59ec014e46f1daa7380d1.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '241512f147e2ed9043d1405fc30fd303',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/38e4985e9b57911371fa49dadf864b5c.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96563ade64cdebec9d90a8a0658ba308',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/e8cbc7aeeb22f9fed7755afbafbcbd04.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '454a6ae9ee828e7c44767943bae62aa3',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/155694cdd6625506310aaa08f0e7aa9f.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d6b4f752c4e6dd5fbe6c71f57b9ac6f',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/3d26bb7d1270eac42a37b7a8bdb164f4.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f084a5d63076006d78c362449608f7c',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/a17597e71ad41ec36f6ce05e25520abe.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ed499d0419c4a29c01cff75d36d165c',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/be5fab49f8cbb5d495164b324d3c9547.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da25a581831f4e49082de8f8ca045037',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/7503b5b6636af9f693af407693486bbb.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99b0702588c9ac653286637e26167d4b',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/9ee093c403eb71b6409593f25328f296.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a80b8b5d5db1e15b84827e5414040463',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/1cad883bbc5e6f351b3cfaffd553cba5.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12d68c42dcebf33310ddf0e4fed02978',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/a4231156a1eb34186fdafa8dd432c6a5.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7334206b273453a1284202107921cc90',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/3f091f5c2e2dab0416464a6d4b67ffe2.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d9ed6dc68ccc85eef9bb35038f15398',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/ae0258c839d6c264628c1bbea507af8f.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fe28475b75a0c6b0fcbc6f6777df42e',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/b4f6c1546abcdf62eb1542bcd93f2953.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0068ff7e66f9fad1570e9f82addd89cc',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/fdc722f16f016f17949b4e49ba993a3f.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0ccdc90511fcd4122a20d8c92d20f46',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/f1b24d0a0d11a1bd78b53f8c3b72b26c.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad37b2c6e048577ec06bed2263309f4c',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/10bb1eb463ba088877b83cb21f368dd0.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4320e1564d8ae79ad2227e914ec5410',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/8dd133bf5c707091c78c3f2a34293aaa.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '911d505afdd5213d509ad490089f2751',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/813d382b5ad3c5f1527bed809886a2c6.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17a466e92c617ace0d111de755533e2e',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/bd71d6cd373ac5e220ff5594b7e6483b.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18427d693ce4843ed24c42dadbf9af93',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/2e42ef76b3bf16ffac2b9eee29fa8909.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e242447ee167da836ad696f1852d8388',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/3eb6c2895c0e954dd8923f32f1b138e0.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0f3ba1573a16e9ce27360fdad5edbad',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/ba073bf3385d3bb5156eaf66caeefa94.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02b95a983acb9c1e34c9ff75dbb3dc7e',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/14a76d70a2a12770a135a2859d3b7d77.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75b1d61170a06540ab84bec706b26de2',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/6770230e61db151ff154ba1a6005f900.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46c3dd01e1f9d0a750da0d70f49748cb',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/c84381fe537ef57a8bff280563c73ed5.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22eb433306cacf18000e643a41fc6ed0',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/cd0a1058716503207f33017f76c49759.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0f0742d430642744b5f9b1f095ada40',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/de8e1e6ed4831ea4ad14f2915b69e4c8.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1312449c64bbb1960f64cd396c32c910',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/05f7fb35ff8328812dda8f47a777d9a0.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6de483812006855e5808630301f972ee',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/e804c173e1aaf9438b2ee9bbeb7b7ec5.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54f869eea087e56bb3bb9f2a8bc6b138',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/0e2dcde24ce5395125d8d2b20786baac.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6749320ee6d290c5c5115d01a2c5aa37',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/d5ea36ac0fe2601aaf4946cc0a32e75a.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88c04f6489345a1d279aff73d8236735',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/47765fc0df0c766c528b3aaf7c649e8f.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e562514232ee69341f69452404f9c974',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/00250407a0305b525b8e61167a8f2556.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dfc8ad570a157d5f35d27e9f901c3810',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/7d4a18ea1d1bd715918e8fd73cabcc7e.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b027ea90d4eaf8b4f1f52310ac627b4',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/6d1208969cda94780de1c4156bfeb805.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5d104c374817b1c83ecb8f1efdacf69',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/c57a04c09e3dc9c543edf233d545a65e.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '143dcd6f962e923d2545703e6580f43c',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/fb24e865d7a274a43707226b220c1d9f.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d9868ea8dbc9be0c36b00a8ed4a3d49',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/16ee8cfd0f7a864789c1c94dc9a06142.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62e14a364f11df5c2dfe98dcc2d4eb87',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/3b50428dc0e9c8e84015b140d132c1fa.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dda0c02bb648095f26b0d771fa7b9ae1',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/20097200e65f28127f0a0e1591f40326.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fee580749f89f184da961c97326da0ad',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/6cd778f16c4740e48ac7a30faaec7899.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c918bfbe142330465698dc5b4d5c4bf',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/0668101334f0577b5cfd40f17664e043.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a0759ff2ccf906002459d7ee593885a',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/fced24a720db3ddd2ab9df5eb6729f67.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2b8c0d1795b96c7ae212d213e74a87a',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/0037822901dc75d24b50811302e36575.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1cccc43f1c7ee45499002e32fa117296',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/2b4b1363a4cd782d7aa84038d15dc86a.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17210757c93cd0bfc657c492e8e87652',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/a5a8180c7ed14d0ff1727471d0159cc7.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eea96139059310019c412779791ea467',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/7844f3127509570f2a41eb9b455b76f2.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '338be89a084389288e692c81566ed95c',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/016e09d8e55ffacd24b4b1b84b5bf368.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c968ebf9898d0a551716c54ea1f49d0b',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/0a0e415828524246fbb8efd1cc4fe247.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ddcd5c5524892ed667e5fd91ea3e243b',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/160d5378f5e6b07d6560937319ee8f86.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'add95c59e1d35df0f867548d032987ac',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/4f4aa68a9e20e47da7ff98b6ae099dee.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e521714f261e272ee6bdb074d67d9761',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/9c227c5aedb2905f31455fcf95b1686e.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3dda2aaf39e16e031128e884b087bf5a',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/681fd1ce035507c31ace3f7c0df73056.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b79bc0f7b4578da09436d8c218c90772',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/1dd2bf68cce8fef1e8f3bb096f09a676.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a7dafb1df02f4154ccaca9f1210b0bf',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/39dca290e72029de9ea4d5389c314929.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d2ea395ba6e9363d0f6a3ae24572605',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/3df85facee4b9b82c309b0223b03d42a.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33b8d670994d4431d729fbb2348d303f',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/52217087240df13cef67a36f5af88d73.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be2b70a4b1656e354c40ad2ab1610864',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/c0aba566738f5cf6edba9d565e5fa5ce.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c81887bf0da9fd282d95b2d409acb05',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/f27efcfcaaa281715204aeccfc53f256.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e60033112fc019055a8b4cbd39594be',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/909d4b5e1fee9b785222f8eeb0bb32dd.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da9a29bde855a300a40314388c511956',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/7e1ad7dc07e8ced88d448b5abffb9682.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3db60525a9fa82b22139c3348407b35',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/12e8015d198bb7998ad2a484d716c476.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfb44efda650f1d38477c47217ec29ec',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/050d72037e40ef74d4a41680c35afefe.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7c97317bbccd5440bde9f468d51ed01',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/d1fe267eea94f377f8463c557e7f9089.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abde5c4d70ce59d328cd6d9ca8e5788a',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/3c9095d4b8bbf30ae28fedc0183eaaa7.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7badd635172d7b873331fe71b67858c',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/d86c5620e1e86b56b4fa6ff1a450e23d.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '449cde750c980d81e803e624ca81ac2f',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/e7410ae3793e232528bb8b81dc5cf2d0.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcc5c93c56e81b99ca014b53cdbc369e',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/56607b42c249fb2f23c2e709fc163a44.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10d6e6d5eab3d66cfe5218536a27b53c',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/3b8ef7394a4a8d3f6253c846ca6b58cb.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c69a0cd754779bc21cc4cd930137798e',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/3f9ccab9fdd1b25e66827e3e13494df7.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b11c704ab586e298d46de679032b601',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/32dd4065d20c6f0138ddd57084ddbaba.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11cc3e2e0a182811a7eaade6941c8a34',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/289c6a8a29e2ae9954cecaaca83e3a0c.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3e9fc7a4766963a40c05b1a17ed3f8a',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/3032aeadb2af823ef2f6577866f847e3.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b3c23b78532508de2baf9cfca51310f',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/ba27b7d50fdee39e1cd88c083daab1d4.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1ef61880f875fdfca8fcf6482fbe0f9',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/ec225a932e782ed687a8fb5858418a92.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcc9cd0e41eb210cdf432cca8a4dc746',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/6f2ac3029e3cf22d2bf3f829f5a0a9a7.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63aaed397742cf6821761fdbaeb5e870',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/2fda4fdc4651db8638ce4686741e5610.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f462a257ae7d6df125b18a23ad634c37',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/3e0951a78d5a5c2e99cd337ac532e15f.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfb44b962f75713063679e07d97c7a23',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/87ebd1556f9b8df5b96e9f86820414a5.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a45b01c345851b3d09ea23535ead2782',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/b6dd8b77f86c5c9197dc356c1d87aaba.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7564e96f04ac8a2a461d62ddc839263f',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/00c2d26c2a88d17d34fe714bec188bb5.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7079803bcb0da6b7c4a55fcca761b2c',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/56784d2897eaa23b4ae8b07df505ed16.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05a914c762dac946255e8c40f7d372e8',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/8501fc8f15011b195312f55026a9a8d5.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18f0165b7d9cfedc3ffb71713304597a',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/8955a21fd86440f8177a2d18b12d0efb.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3b5a19d0648e30c2d140f4386024b49',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/c069f89ac9f061d5294b2d73391100e2.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30482261372aeed8ece28b3266855e35',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/1958929c88c4d19b5a6f7581191f6b7c.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f281ecfabb6974e298f81f2b03f34f55',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/b4ff6a713a7a408831f16866acb50fc9.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '957df931d1652c6f6efb4c2eca5d375f',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/562c427855d2e29a35a5500d08ea381d.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29f3d25be4a0773714cb0a2bfe1930a7',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/36b532de75f8cc64a9c8f80d0a268a28.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9ad98a04760a25adeb78b149ba1cb74',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/f364affce2f03ae942c1adcbf1665648.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a11815f38f137e76b39de80977f0b83c',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/9aff9b1eb6776c5afb9a5fb5e671fbea.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4ceda8f56fcf901e7a76d3fea74a47c',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/aa53175ce521c07a5280c650b6fe1446.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a29c5aaf4e08706f0d34b9eb4af0ccba',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/93b07ae9d1608b9ec41467e74039b583.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2abfe6a223a5a38d94f4679fc124f93',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/c20ba71aea247dbbe2397a307e666aa0.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e7188264398b6b293dc9ceb9f78b7bb',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/9b07878cb24e35c1dcd800585e757fa7.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0edcfa1c1a6deed7e396dd0004989efd',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/826ff46142aec652aba3ba4a1727dd3d.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '917d0b1a4621f12b7d891abd433376cf',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/f7c16a569cdaadc60b6978505aa0a4f4.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3fa9718dbd841cf4ee73788e528ba8a9',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/d36d544634cc00b87d6ad524d3c87232.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bc3e05bb97b73856efd6d4918ffa4bf',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/44431816c7bc4d2c076f89d0afed65d1.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14a1108f426a030ce3e3c3844aaea591',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/efa0f2716451b9cfce5abe7768ba5706.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '615fa40187c84903f3341c3da57be3d0',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/fb34c454df5fc919e631872242633bc6.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3526651a6d492657f2e9cf510c5e9f0',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/b214a9eee932a986af89568c999cd2b6.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f0d801a7c60fe27dd29c30733c252cb',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/f5a006c1d37321cef7e3662bda5f67d4.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b824a6a8e945acca5abbf265d9865f84',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/a0ca2a68e8ed00884f9e37c170331f7f.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9ba664d3bfc2d50c2011e79cb673f65',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/993a9bfb8ac09c5382383321826da65d.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0229e8b14bcf4da762a22b6b53e4607e',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/7911df675732a71fd2d5a0b6e929734e.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89f943ac13a826c6abd9b49bb5c07458',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/4270db3424c52f7bbedd15d627d36c4b.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e84249f214e41bf51941c85799aeed97',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/a33ca2c903fff5d672ba1d346d193583.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67a6c5881ec05c52f77fc6d8553adfd7',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/af2768592627086bed6829e6e147a9d7.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61190cfafc15ffa924548da5f36ecf6a',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/5de7927fa15bf9e32988ffdf6740e211.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b91aac8ab965c2411f928cb8f4d9b7c0',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/b437cf2bd1ecbf82a130832a2c5bc368.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcd5dd4b1a5b0e749db5f512884e422f',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/be962d5b0a389874aee5fed022943d74.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55589db5029d837182a0c8b6e3eb22a2',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/42b685022b76c63f4beaf2cc56db7870.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03cca4725a48f66ce3516cb476ffae05',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/3b481221524412e18a4fc71ffc056db5.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b73dc6d7a80b7808594c1804f224e63a',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/368cf0f25c1f4d16a9af928737f764c0.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7c64f43e0709b71b2ccc17ff5641e51',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/a9e1aae0775c1d53383bc5af4052fb32.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db416b65ed119978f3f617e1022f8a05',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/55bf51852c6cfb6859769dbaf7a33734.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8120191ea30926aca01399af8a1601c0',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/66cf0e1faf4dd8eea06dccded9f06dfa.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa56cda58d1f00bbc3ed45f799d2f760',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/402061853a8eea9fef8ea295e794243a.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7ec51d3afe21fb19e0db0415f0e250e',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/d595659265a7847d59abdc698ae74b75.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55b3ce040699b89815a3142daf88ca33',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/b6c25de2072203caeb5e03db8860821d.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a086fbbb943b6997d2845c73dd365f8',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/b95ab8fee4312b9fc6486641133d3248.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f400ded2915d8e3abaaa6a0aa6b44226',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/2239d9a3bf113f23658fa085e387ba0e.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03342e6f2c8da566c5c231a81ea8e2aa',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/5765ececaaef5bcd53262cc41609b47c.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58e0d64733b4a961d5c39dc67f304e7b',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/982d6a043b22a22a5e95833da066a1f7.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91df93c00d1b39dd6a9e91640df98972',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/434100540a0d8f1f602c1f537b8afa5c.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e83dd61dede7ed03e93ac41ba5f7c430',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/b80430c78f00219ff164f7dd891345f9.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44e9476b7e1d364584bb3fc90cbd40fb',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/af1c44423a0d29324de082e9dc0fd71f.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67f8ac76a53bf3710cd6eb5fcfaddaf1',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/23ba63e9b9dfa9a2c9fb51b9bfaa2a5a.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca3579eaf3e42487cd07cb0b3480dc69',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/7a01308493b1f76d3120becbcc7687dc.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fc469e33c27ad8866f10de1c4ade235',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/12332828dcb6aa413d622a2b7cf528a7.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c75317f03b962da291d64f89db1d805f',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/4e00a6245c1c5348ed005ee676d7199c.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a04398f3063ee60a786852907d694462',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/4f63491eb2ce708aff065a6ddd340b0c.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '497c54a1f73e261aeb19687aa0af6e9b',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/eb2f011c8e95d541ea236e3b7ca705c7.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b36251630e728d8e9d4b12345c647cbc',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/da149c465a71fb3c34ede418efa5e6ad.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '106b519c82e9628c32ae75fbfd72d209',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/5e1702b27d45d95d5b6e1eb0f67c1c80.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12ebf653282ab35eb4cf6fac914d87d3',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/74021f0684119a222d8a87430bcbeeaa.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f894f5ac41d77210541d65b5c4a7d5a8',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/e65f49730f657e4ccbda79e2c1d8fbcf.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fc7a8ef579eb6bff244a4406d49f71e',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/70f129ab7eb21194700f6922cab0aa40.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'effa6f54adc9d476c28bf1c34728e9b7',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/5aaf43063064518651e9e5a4dd370680.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd256cfe2a452022d1e98898d434ab2d',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/6d41af4a5593c1292be49b617579a780.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ceb5f6af22147ccf1b278522d41cb605',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/bdbfd7a24a417528f74e91a93b333f10.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '558c95b80270730fa020855c60bc0e69',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/2ef53e639fb186e7e17984dfedf20bbc.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '346926352e1a371c372f3b9e43d12a00',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/3e4e5588a354cca7a3b4a3e603372650.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02c4bb7c18bac61807cc69ce02b84ca4',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/46bd9538b860498d3934e7bb01d2bb6b.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '028893e99dbd4f154e800d9cc5911be6',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/efb07c9b3ab1f8a834f59c39726a581c.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a04d9675fdfa45d8d05f819d4b040541',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/212a434ab39734f81de391d56c88bfd1.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6918fb25527e984e7b5ee360cd82351a',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/2137c46b74db9ce2a1f584f47a6bf049.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a9dad9e2e6a7366c02212eb04d9ff38',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/da73e6d55466381282eee0e5cf705f30.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d0383743a6834fe87b532499f7e9470',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/2488da66bbf4045aece25ddf2df15311.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e533eb2957fc2398726f719dff3ac565',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/df6b93a1cd75e584dc5a86cbe0a31f17.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28016973f08eefafe9b93ba0e8d42401',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/250926224628a165b63247f8920b3cda.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db1c3cbc064cdc938eb0e134d41280e6',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/5c662291fa16e5d245ae01a3b9b08524.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3814a1134d63a2585ae3dd64b0035d6c',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/27d96e0ee231af8a17b8e4e70bc9e5ff.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2da584f87faefb72a3c85926234c4bff',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/b5f2b9dd843df5730832a6afca68a5a0.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd422a5dc6bbc37111359146f2082681',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/ff2ece1cf00a0c687060637f5539dd7e.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e7b38ed50750ff621779afedef15c50',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/f6231018836dad7697e8100d6ef41b80.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5822118ab8877454181b6e3fa108e547',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/2102d19d1b8fb4b79635ee4f31a1b791.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67220ac4ba2103a26a446dbf79a680e6',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/3f9d7f2381045332ce08d3e5ae0b89bb.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '741f14f530b2fd9277ef6af2b355809f',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/a69c9679b36435ac5f1bb72dcc6c6102.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cd614df60e711871218ff7b4d9a64c3',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/ce40dc17416be895a79d65ff867176a2.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e28037ee1dc8566320049c7b6bb27278',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/d4e1d4f5d2ae01efed3a8f8825c9abe9.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11d91efc9c7c562f8d94b71e4fb37dc4',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/0d81c3ca5d79f98cf590da109b8bed43.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8be2e85547b3c1214abad8a8526cd104',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/55ad65f6de2b51cdb1981747fb83312c.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '276efabf67cb1f7d730c43a22d8353e7',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/92344fb333601be9eb88393a1038254e.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca10105c8e93a39ce5ed713020286ad3',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/14ce1b57149c417715d185bad683ba4d.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09b67a87f3bedca19b290f34aa5b9c65',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/5281a8400216c7c6596d290d95a605c3.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3343090d9f44533f7439de696f782fc4',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/1cc12fbcde4ec455262e26caf5e2012e.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ef1fa50b36fd7ee489f187b5184eb99',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/6c244cbd73e555565fec4bae3b3c3f9e.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f2caaaed8d5df685d4aaa26f69e08dc',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/9bb299f62bd06b28d1b90f1cebd217b0.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4bb2a6b45c1580d0d700f0bcf3b36ec',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/b99ef328b29d2da4dfc55304140e5ab8.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'badf13d0c09bf0c8d1a191026e507101',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/e9ac82c64079a7b1b74ebdcb11f78d07.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efbe0bed6a9d1a3d70ecae79e88e5000',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/130729d044a4b1a9cd7dd12e473f5517.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2ea8d6999c47bb60a77b7880da0a7bd',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/67a14f07abd56a8ade38419cdc267877.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33ee91991120bd72cb036eb7bcae61fe',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/2a557d652d5c47cc12749a3da06f8c69.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6ac005b0ffb3dc5dfbf7c2a86c539db',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/a9410619a3b130938e5127c4f32e6782.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60bdda9d5e3c09d3d1ab33982296cc3a',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/8b7ed1b0e6492a985e1c46770673a12a.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e517eef30ccc4cba14f5bd336c982c8',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/6b954e25dab4a91d880c9d32f0588fee.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cad68dcf42ead0f08646df5ce6ea06ad',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/c7a939be3803b3eaa496f71b1252e296.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b17a3e96139857d8514628b2db8f2a5d',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/7009eec765a1db36ab887f2492653dff.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f608beea6ab20117ad2dfcfd0cca8e6f',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/63388e00b1bb806c619b4a186ce6cb21.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e8c2844042bd7fb55649cddc0728223',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/82bb0ceadf819aa2157f163b574a272c.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72cc364ed11a6a24b6295c72abf987d4',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/731981f927a087505768e9901b8fd283.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3ac18577f72494ae1302a6c87f54c1a',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/186a657decdce80e7d3ed2652bca4293.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87ca7bb43d4e214a936dfcbc38ceba4e',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/18528547f267409ed91f1a49077fcbef.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d343ad311c96cf2201b3af9536264f3',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/d4d2710c05a1b96bd2538709e0aa8100.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5aa1671147d93db9722472c95596b11',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/17c6a0026399c368f1dad89c828f221c.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b39c03db4d99c040d7336976af48e1be',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/538f6174b3b36fc100c5514215b91acd.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'daac0fcd1ea19cc3ba4f917e662952c2',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/b520bdb5f4ffe1363d4dfe65d9991343.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d498d4896aa89047a2efe50b79dd5ce',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/123b3fdbd2fff2568bc956c45b2229e1.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ea13dfbf948050164e45b7e4f60d1aa',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/26b5f0aa88d9721fc0b692999ad460e4.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e88c287d83f0b3b44780e5e1a109f70',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/f3c05e0dfa9dfb6a95db11266f84a345.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b9694df16e5f5aa54748c11cbf5bba8',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/07e67078c0ca2121ef1da49a5c281cda.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f50ec66249e14b8c3b8a44fdd584abe8',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/72ecabcc25f528fe4af9efcb5729704d.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ece25e2e7b57488ab97c3a07639c951',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/a5902c460b8193b4b1a64a6440b03619.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d4987cbce1ac7531cc5325fb51ef639',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/17a646495bda8fc224a4b98b165e1b16.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77878849234419cf4b22235c98e65035',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/08a3e69e76bebc47de355fbb36642d59.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5f117d1c55ddfb5153bb9ffd48b7b6d',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/e92804d4b2406776c6ad92d9dcd3d9ab.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7e64561a2f6a0a6e9fe9947b57cb5f0',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/6a2843ad75d77872151de4995e0e308d.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc8dcbf0b69c12431269a6771613d9d4',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/ea206128a355c216eef643a06145529e.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fee1294fa82954e2404aab9d29bd2e8',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/3ba0e517d5a4433e203c4f4b1c9bd175.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3e5a52b51a920838c680d781cce4879',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/52bc47b23d8680ea85a9d8b2b915d2fd.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '117aeaaf4759c9072075963f87e2aa39',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/db9c8de6fdd095cb2bac7c81613b938d.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '790e716c41fc3ed362984ab1bef4ff0c',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/5e7594260f964879e9baf700aeaceff4.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f325078551d2263313baf6d07c90edb9',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/058bead6471d3e98e51d21e643dd4333.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e51379f0d3539979613a451497db409e',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/04d6c9670b9e65916d4e5ef1ed3ec8c3.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39498a1e769975320813883c9da011fb',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/1fb522bccf6a3220cc7e47cd3b8cb74f.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3f8979f6bd61d97c8ce7db2aa7c1023',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/d1c6e22dccfdccd44500d65d076fab5b.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c338e435fff7b0b6dd4f6d3d52441b09',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/02a73291758992a0ca9075f8a434e05f.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac2f8f090ea7de83feeef40837177801',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/923810dddf89dd21589f34a622080319.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dbd6eb4d1974e011d6c11bf92056d1d',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/bbd887b4f035c62cb143e734027d6b46.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a95ed8f1da5c9c57d774fa4860816e3',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/aa002025eda10596d80d561ce3d69afb.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67f685abd23d2f62674371617f77ebcf',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/d2751f735bda4eec7809a0fdb545eee0.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '569a2c253c25dd47a58c8f82f3670b4d',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/37d67652395e0ae0a46745857e01a423.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '575af7ebcd865deedaf15af7e8653820',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/e0b3ff1509a0006d9e0212359b4f484f.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcd26446729c6e0f60fd55cef64eff7d',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/8b8ac599d5f84d6a4c04ecfc601e0798.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98b0a90ab8fddf9447b6e956eb362a65',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/f6f0aedc150b7d3099bd384d3512fa93.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdd2efcc9a69471142c229e80f74584b',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/bb8bed638a5d8f4c09baec33a500ef46.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4f60257d501554487d040684b342062',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/b9f919e159f3934bc434eb85ee0ec3e8.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77604c0cd30b887662d22432422de894',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/ba1f96db2635ef88c4d72bdac0c55668.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a3179769064e215a74ab23e29b56d6a',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/5ff67b3ba6cec5d89e97bc07cc2f3326.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce6465e1b780bf23d3343e99339ba363',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/7e3659fd96f81629396e127b8ec79bfa.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c401682c11ae907f1ef69b9711e34704',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/86541a9363f337aa8320efbec5d6f17e.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00f10fe5b3efcff9cabaf596e77f4d0d',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/beacf9359636496910a6b6fd283fbe3f.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b25f2396f7d2369f975d1e5fc1487360',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/b8f768582ae61f03b575e3be67fec5eb.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fc437b8ac7788f9340f280a16309b06',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/5776f3d82d877302730524e14884f981.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fbc3fad4d8150a20ca9bb7598e2ae8e',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/d84c34426ced46a2e5b22d97295872eb.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d76e9807fa0de001866753edf9c45aa',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/f0d97c870f4f9308745600c5b64713d1.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd76582466d64a8887af44711a9c80dc2',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/773749f32c457a4df942026855a05c92.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b94a37fa66db32ea376e1a813dd6791',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/10f404a1b5cddbaab3d5cda92202d6bd.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bb4168807b2da52b73fb965966c3fc9',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/956113b45f919259f71f4fb8a4ad217f.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d3c207640a65168be8f87dfea66c8a7',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/674eb20f414d9f690f20f4012b9505cb.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e60e9c0ee4648de647531d82fb550cc',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/ceb1c1fdcbf828fde31e0369991bef27.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd672a1c3154fe7640afe4730be1f6e59',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/bd0dba7adb8cb2c0db431086065e8138.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcb7df6df4784bc7561b07247e9e7ff9',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/a81b08da4f95c266f4cf536a6cf24526.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b983f2c4e70e6bb069d4a233974bcd0',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/6e3b49ef0bf0df2ff8a6ce1470917f18.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70c3c0ccc6164ee2ed81ac9fd2213882',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/c886781da89803f532002b56077dc3e2.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4350fd299835c64c5c3e5f2cc419257e',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/10c9393c0e5350f307a3b8a2730a50c6.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b381132afd3ee50ec04e5c0dea5fd36',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/932b61d714a646747c7afdaf06f98f1a.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29ec557381caead8f1cb79eddf74c2f5',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/679343cde4e70915be4a00445d1d21f3.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '653a68ea1b28ac276a65b0b55f0bcbd0',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/3b9517f1ece12ebdfcc8da294354a185.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bc3fad649f925c3fb9d66c026f47d0f',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/5736b28b50ebaa4b4188b36702c15c89.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84a7b5830b50dec170b476d4f90c0311',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/d300dc95722b4f8d19bd45aa38596136.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '967e66b66e55df9b1fec4d67d0df1dda',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/20e08c1c8941f7ab680b7f96be95984f.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bed5284bb90a69479907b9b4c0d3495',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/7a74adba25d10ec126d6783f451fa4ae.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90d88ec2312b382978f5c1c0cefc7024',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/1c52f74d215729a0af3e409eeebb36d7.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96c780eabbddf1a9c5e23d3c8af6de52',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/46ae7cb11ae6f391821ffbcecf0911f3.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4cb7a73c7924979bb0b1f7f66a27c95',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/bfd96c93cd84970c3213860874f50180.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '831ee34b10dd12ceea695ddd721054a8',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/ee9c276375ea75219593e8bb7944aa2f.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58c2c41f440f600d94fa433da3a3ed65',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/134a740f7b34324df0a648a2b0c39f46.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dac2713c1773a544223ea39c23520c4a',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/f189399e4817dd38d986b76f4dedf34b.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06e87a3aaf8201a82b746a1b81e4d378',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/0193189ea2e6352284c5a4c8190acaef.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '326fc3b58e77f5d752c05a9cb36d2e05',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/4ad481d2c89bf3be849d7c7cf2c145fd.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1adbeffdf817be4327f2823845acce9f',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/61b7d6f16d5afe54f83629659d01a154.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7e842b7653584d3d81870113a6fa65a',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/a237e07f848ec29256d6d8f31a4fb9f1.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e71683ce77dea8ae312b7fdebe28f26',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/1f1223748b59c472e5538c7fefdec9b6.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '123396e266ac20891aa55e11d6793004',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/a3cd7728954c7735a39896ef046b81b3.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdaacfca1039f82310ba57b628d67f26',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/fb20af4cc00d7c16a415441818b1b6ca.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8848546b8f8166c5ec7c175981d1c32',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/c03249ca410c5a0111042aec42e1bfea.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '705ddbd46c0f36eff06670489d5f21e2',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/04ec7fa63ef176a3e1d61d4a74461a77.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9b2f5af3e986a590366dd7191344d9c',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/caf3bf6dbc850568f2389c3794f3fd82.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a96300090694af1decb5e80ab198478e',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/438d182cfbdba70a219cca7bf0b21bd8.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93104816ae2b0bae557271bf22d3ef8b',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/c93e55a0911feeb7c587523a758df9c6.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e7b6356dca092b57a1c53112c1d2ee0',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/6b5a0546d9e1190a13d7d011c1fbb381.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c70b82b8b6d6a8c6a4b9e60d2cc7f444',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/694f149f87c1d733e4dbffff79e0c6c2.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4032da7ca384ad938faf6971ad904aa2',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/eb091af27c34d84cf1138070dc509437.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f518c82ade53ed05efbad3e74a1b02d',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/63a2c90193756edcc99733c5f36a8631.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83222d0de8b36ebb053b6ba43e303747',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/8870eca31612bd8476f547f8d91ac4a9.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69a3a2c77f15b16fb8fe5a70c641d84b',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/15f789238c2e6e8708807fb925119569.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a99cf013814ff8185e2c450c629b97ef',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/f5277a2c40e00cb1eb99669d91100239.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20d7f2ee111f6d75cb065ae74a1e536a',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/39db7bf673f117f1752bb57003780a8e.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdedc3c78dd8bf842b9425af6c56fae3',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/df537587b6613dd6201b0808f4d22d6c.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e74ad2eb96fb5de83398199c85b8a76',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/ad4f2fa28c92fd246b8e0adac6210d4c.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f51731e907a5bb396984d219eaae901',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/5c81ef3d0668707425d48a75f42926f0.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '413845d1ea6009310c6ceed0fc8e4b4f',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/20f10d93cc587bd2874894a7c1e3f374.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a52088c4a518f07307de8a59275b2dd',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/3329dd1e5653bfc3b6aa572cca1400e7.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f2e11c93bad91e37c40ed4b976bf158',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/9dce93d696ba417c9a72cb67d64b92d4.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a71f834fe578031280524ce569708a5',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/7b92713379c2f6d5ebb01cf7cb24583a.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89054fb15bd183b4d70a8b1604986ab2',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/b8aa33eaa471e3bd8c6a1b3035a6b9cb.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '453d55e54f5c637dbeed0bf226393cc8',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/5e9b3275d54ce42641411c29c60ffe42.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8898126b1f1b95fa7cf94e83034ac04a',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/c0bcb59aea44a852d705c7c95cd8500a.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3996bb837b024e54c5ca1aae779dc51b',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/70b4cc4a39de827f3a68e83ac3fbdb2a.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cef60b3b2a68cbb65c01c07ce95be09',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/d74918718968713e2c0a34a448b2fbf8.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afa49346a64dabb1765b3d172da91c7a',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/4f6f7cfcee180cac949491ea4aee980b.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6df8285d627fdd9718d2275e5a6fc57',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/807d9c7aa2f9f4e14dd7c180084ce65c.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '707624a0f0fd301c6f596eed31f6c73c',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/2fe3006aafddad601aab6c520fa70a82.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70fd366cbc91f5cee4e96c27f01a2d14',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/c41fa4c2942f7c8215b583b6712e9faa.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3dfba8e1dc2bf3135c2446017ce9510',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/1026e2ba538a264e0cffaaa396d7998b.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '89426f0fd7c94c9a88a0a41ca188a934',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/ede5e785454919adeaa60a4e90022202.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'd783a9617f727e256a610540fa160813',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/fd26ed2d17dd2e7c442e253c57d3eca0.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '3db22ec5ff1fc51983447ea7058948ff',
      'native_key' => 1,
      'filename' => 'modUserGroup/115bee42962d2b70f5cf73150b0fc7b3.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'e84e2e6b9fef26a3f0d883994e619e15',
      'native_key' => 1,
      'filename' => 'modDashboard/85c5cf3eb34aabccbd82bff87c78b62b.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '46204887d2972d2d575b757e123c5af3',
      'native_key' => 1,
      'filename' => 'modMediaSource/0c03a202375710b21ff99750e2eca18f.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '837fce97b8b00abf2084311627dfb14a',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/6210da63055de744384d5a427330dcb6.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '9336defb383d097d42375f6c3454bbeb',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/9a4b1161f44338132ab668be91371c44.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'c1f128f2b962dff0506ba5ad5e875f27',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/cddfb5901256dda47b27c8bbcd6df0fb.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '10862c3990bc253b2529196ce680c700',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/b00518c60305a9b8ae649409846897bd.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '6f43e78b3e354d6d23c745ab66ca8acf',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/733f6fd7888c6e1341a3f6dad570bacd.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '51861c2679f0ac3303a6285759d01ca1',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/68fd8f120fa133e2289111e11d506bdf.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'dee3e664fa3d89e92ec013e33c487bc1',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/54fe313fef9977963bfac33c9858eef4.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'bb2dbdf7b8eefe6a3c0397a803936645',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/f8fb3cb154989a29eeb569688a537b90.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ddb89a34d4d7457505f60588175108e6',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/3eea7f738656a79cfeb728341f78835c.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '1ef097b5416b6ed9f70aef570528be49',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5dcbae0226055819845c3eb262969208.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '556aa3e999f5858439228be33835cd8b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/54f64145c4675fb7baa57e0a5ab3040c.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '45e07c758f38466fd6509965fa78f337',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/b41d0d5b311fd483af186b75413d270b.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '4c65ae99a2842646754d0f9afecfa8da',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c5b3c6087554ddc749443ae4ac6af631.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c94ef2f14979f2c9f3822d5f86ff7c26',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/7a621e2cd8a1a9460ca174c315c3e568.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'efee340b08bee0bfa207db8cc1c619ff',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3d0a9741b0711e19889ac78a374354d9.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd996feb6b84256e6decc09b1269b5be2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/54401ca517fd7dba4b84c979f72bb910.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6a2359a86031191f41868d4d7c7f67ab',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/2b30c5bb26ca849a3254f6e24597127b.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6473035b8ee98fe6c7d1ab9dc42ca36f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b022b558bcfbb0e6be7f0c397e656bd3.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'cd0c143bede1a57bcb4c32f9b1f313a0',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/698a6284bf6531da10a42644c0d931d5.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8987627bc1f7025de5693903f87aaa82',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/93aea5c9ddd258cb2f9c6f7e71aedcef.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6bf37adc968bf1de96631a9d2789a363',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/af1e96f93992f572725a6e3481f88e27.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c5f01416dedef50db71c7cc987fc3c45',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/ade675c9542f26e33313872da4f6215c.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '51486d98b9215d4984c0195e73b203c8',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/8a38cee53001bb4bd140cfb4c5c5dcb0.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8023022ffaed7d67ab782fde54db5ccd',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/cdea98683606b2dc195da19f41ddc7e8.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8ef5bba5dd08924d5a5cf82c89bbdd13',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/ffa2e150ef823e8cc7db3d1a563f1fe9.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'fe5c383da85bd75f9187ba2e85936cec',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/88107ec6ebbe24c9afdc219e9e4e195a.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '56caf95a419eaf8cf17118cd4ffa6eff',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/e46d2aefb885a816a9ec44a18cf522d1.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2ffa2c509df40eacbc7e8d51c5cda9b5',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/87331ea1bc06c84f56509c8209cc902a.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '56bbd96bde2539b71acd4152477442e1',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/ef1b3c50d82005e4a45317b132f2d181.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '8ac546b13a2144625e2cacdd79dc93bf',
      'native_key' => 'web',
      'filename' => 'modContext/cd0583f5e190451e0235a81793628054.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'bce6b5f881b0b6e045ca05d5c9e198f6',
      'native_key' => 'mgr',
      'filename' => 'modContext/200977f91595ab9bc0327e1e0ec25f62.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5f19dff996fa70951910939ed0483eb3',
      'native_key' => '5f19dff996fa70951910939ed0483eb3',
      'filename' => 'xPDOFileVehicle/3887269878a173e1fe04e989b4f5e8c2.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5a61d076e9dfddfdf77069ff5bd4f9bd',
      'native_key' => '5a61d076e9dfddfdf77069ff5bd4f9bd',
      'filename' => 'xPDOFileVehicle/fa6ebd292bb065f6ace3a8f4e4e1b35f.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '23777befea5dea0d26860cc65dcb7a27',
      'native_key' => '23777befea5dea0d26860cc65dcb7a27',
      'filename' => 'xPDOFileVehicle/f0debc8b4e99fe0d574659c01ef674fa.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1a071f10f263bc09a0752d8b33ce16ba',
      'native_key' => '1a071f10f263bc09a0752d8b33ce16ba',
      'filename' => 'xPDOFileVehicle/89269e3d5a8251f8a646dac8cc2bdc47.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '513290971b65c34e49a42636deddf7f3',
      'native_key' => '513290971b65c34e49a42636deddf7f3',
      'filename' => 'xPDOFileVehicle/5d852430064ea7d0701b851ad18db57a.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1bc8a7f4a210cff85d258425a305cbf1',
      'native_key' => '1bc8a7f4a210cff85d258425a305cbf1',
      'filename' => 'xPDOFileVehicle/4f98ce9597d116bb0f67901ec6e49bab.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4ceb935aeb54a384c540bdc4d29bba25',
      'native_key' => '4ceb935aeb54a384c540bdc4d29bba25',
      'filename' => 'xPDOFileVehicle/ae4e67bee4eea49407fb1c707c87a5a2.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0ad6feacad473e31100b58789176f3b2',
      'native_key' => '0ad6feacad473e31100b58789176f3b2',
      'filename' => 'xPDOFileVehicle/46d62e54a9a6a0e808dc7b2d10e985b6.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ef6b238487abf844a38ccad876eab0f2',
      'native_key' => 'ef6b238487abf844a38ccad876eab0f2',
      'filename' => 'xPDOFileVehicle/1de5d9d56ca071de3d4a82a5d9726fcf.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7656203f87068cea0ccf146d1b2d5abb',
      'native_key' => '7656203f87068cea0ccf146d1b2d5abb',
      'filename' => 'xPDOFileVehicle/df679566da114f65de52d8f4dc96b2ee.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '56f4fba4977df6d6165b6e2369d4c36e',
      'native_key' => '56f4fba4977df6d6165b6e2369d4c36e',
      'filename' => 'xPDOFileVehicle/ebdf71a63c4ec853b1e8088523de3ffa.vehicle',
    ),
  ),
);