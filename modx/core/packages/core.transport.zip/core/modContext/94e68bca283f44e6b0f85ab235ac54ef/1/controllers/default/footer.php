<?php
/**
 * Loads the footer
 *
 * @package modx
 * @subpackage manager
 */
return $modx->smarty->fetch('footer.tpl');